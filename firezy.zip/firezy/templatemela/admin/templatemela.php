<div id="wpbody-content">
  <div class="wrap">
    <div class="icon-templatemela"><img src="<?php echo esc_url(get_option( 'siteurl' )).'/wp-content/themes/'.get_option( 'template' ).'/templatemela/logo.png'; ?>" /></div>
    <div class="tmpmela_contents">
      <div class="entry-content">
        <p><a target="_Self" href="#" title="<?php esc_attr_e( 'Templatemela', 'firezy' );?>">TemplateMela</a> <br />
        <h3>Extremely Customizable, Responsive and fluid theme framework </h3>
        Make your site shine in few minutes by choosing from any of our high-quality premium WordPress themes.<br />
        With our hundreds of WordPress themes to choose from, you'll have a stylishly professional site that's sure to impress.
        </p>
      </div>
    </div>
    <div id="ajax-response"></div>
    <br class="clear">
  </div>
  <div class="clear"></div>
</div>