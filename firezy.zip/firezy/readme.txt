=== WCM040092 ===
Contributors: the WordPress team
Tags: left-sidebar, fixed-layout, responsive-layout, accessibility-ready, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, microformats, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready
Requires at least: 4.1
Tested up to: 5.0.x
Stable tag: 4.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
